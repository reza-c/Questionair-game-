using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SoundManager : MonoBehaviour
{
    public AudioSource wrongSoundEffect;
    public AudioSource rightSoundEffect;


    public void PlaywrongSoundEffect()
    {
        wrongSoundEffect.Play();
    }

    public void PlayrightSoundEffect()
    {
        rightSoundEffect.Play();
    }


    public void ExitGame()
    {
        SceneManager.LoadScene(0);
    }
}
