using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Transform target; // The target to follow (usually the player)
    public float smoothTime = 0.3f; // Smoothness of camera movement

    private Vector3 velocity = Vector3.zero;

    private void LateUpdate()
    {
        if (target != null)
        {
            // Calculate target position with some offset in y-axis
            Vector3 targetPosition = new Vector3((target.position.x + 7), transform.position.y, transform.position.z);

            // Smoothly move the camera towards the target position
            transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
        }
    }
}
