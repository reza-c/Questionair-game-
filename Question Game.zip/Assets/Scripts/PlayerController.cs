using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public float speed = 5f;
    public float jumpForce = 10f;
    public QuestionManager questionManager;
    public Rigidbody2D rb;
    public Animator animator;

    private bool canJump = false;
    
    public LayerMask obstacleLayer;
    public LayerMask groundLayer;
    public Transform DetectPos;
    public Transform groundCheck;

   

    private bool isGrounded = false;

    private void Start()
    {
        //scoreText = GameObject.Find("ScoreText").GetComponent<Text>();
    }

    private void Update()
    {

        isGrounded = Physics2D.OverlapCircle(groundCheck.position, 0.1f, groundLayer);

        // Play jump animation if not grounded
        animator.SetBool("Jump", !isGrounded);
        //if (canJump && Input.GetKeyDown(KeyCode.Space))
        //{
        //    Jump();
        //}
        

        RaycastHit2D hit = Physics2D.Raycast(DetectPos.transform.position, Vector2.right, 0.2f, obstacleLayer);
        if (hit.collider != null)
        {
            
            if (hit.collider.gameObject.CompareTag("Obs") && isGrounded)
            {
                Time.timeScale = 0f;
                hit.collider.GetComponent<Collider2D>().enabled = false;
                questionManager.NextQuestion();
            }
        }

    }

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(speed, rb.velocity.y);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Obstacle"))
        {
            // Display question when obstacle is detected
            questionManager.gameObject.SetActive(true);
        }
    }

    public void Jump()
    {
        rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        canJump = false;
        animator.SetTrigger("Jump");
    }

    public void SetCanJump(bool value)
    {
        canJump = value;
    }

    
}
