using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
public class MenuManager : MonoBehaviour
{

    public GameObject startBtn;
    public TMP_InputField username;

    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }
    public void startGame()
    {
        PlayerPrefs.SetString("username", username.text);
        SceneManager.LoadScene(1);
    }

    public void OnValueChanged()
    {
        if(username.text.Length<=2)
        {
            startBtn.SetActive(false);
        }
        else
        {
            startBtn.SetActive(true);

        }
    }

    public void ApplicationQuit()
    {
        Application.Quit();
    }
}
